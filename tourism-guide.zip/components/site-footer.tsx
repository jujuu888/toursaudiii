import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SiteFooter() {
  return (
    <footer className="bg-muted">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="font-amiri text-2xl font-bold">المرشد السياحي</h3>
            <p className="text-muted-foreground">
              دليلك الشامل للسياحة في المملكة العربية السعودية، اكتشف أجمل المدن والمعالم السياحية والفعاليات.
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <Button variant="ghost" size="icon">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">فيسبوك</span>
              </Button>
              <Button variant="ghost" size="icon">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">تويتر</span>
              </Button>
              <Button variant="ghost" size="icon">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">انستغرام</span>
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="font-amiri text-lg font-bold">روابط سريعة</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/cities" className="text-muted-foreground hover:text-primary transition-colors">
                  المدن السياحية
                </Link>
              </li>
              <li>
                <Link href="/heritage" className="text-muted-foreground hover:text-primary transition-colors">
                  المواقع التراثية
                </Link>
              </li>
              <li>
                <Link href="/events" className="text-muted-foreground hover:text-primary transition-colors">
                  الفعاليات
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-muted-foreground hover:text-primary transition-colors">
                  الخدمات السياحية
                </Link>
              </li>
              <li>
                <Link href="/ai-guide" className="text-muted-foreground hover:text-primary transition-colors">
                  المرشد الذكي
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-amiri text-lg font-bold">معلومات مفيدة</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  عن المرشد
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-primary transition-colors">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                  اتصل بنا
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="font-amiri text-lg font-bold">النشرة البريدية</h4>
            <p className="text-muted-foreground">اشترك في نشرتنا البريدية للحصول على آخر الأخبار والعروض السياحية.</p>
            <div className="flex gap-2">
              <Input placeholder="البريد الإلكتروني" type="email" />
              <Button variant="primary">اشتراك</Button>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-border text-center text-muted-foreground">
          <p>© {new Date().getFullYear()} المرشد السياحي. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  )
}
